-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: shkolo_project
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projects` (
  `project_id` int NOT NULL,
  `project_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects`
--

LOCK TABLES `projects` WRITE;
/*!40000 ALTER TABLE `projects` DISABLE KEYS */;
INSERT INTO `projects` VALUES (1,'Екологични иновации в училище'),(2,'История на България през вековете'),(3,'Математически предизвикателства за младежи'),(4,'Човешките права и тяхната защита'),(5,'Икономика и предприемачество в 21-ви век'),(6,'Зелената енергия и бъдещето на планетата'),(7,'Развитие на информационните технологии'),(8,'Културното наследство на нашето село'),(9,'Възможности за рециклиране и устойчиво развитие'),(10,'Изкуства и технологии в съвременния свят');
/*!40000 ALTER TABLE `projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projects_students`
--

DROP TABLE IF EXISTS `projects_students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projects_students` (
  `project_id` int NOT NULL,
  `student_id` int NOT NULL,
  PRIMARY KEY (`project_id`,`student_id`),
  KEY `fk_projects_students_students` (`student_id`),
  CONSTRAINT `fk_projects_students_projects` FOREIGN KEY (`project_id`) REFERENCES `projects` (`project_id`),
  CONSTRAINT `fk_projects_students_students` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects_students`
--

LOCK TABLES `projects_students` WRITE;
/*!40000 ALTER TABLE `projects_students` DISABLE KEYS */;
INSERT INTO `projects_students` VALUES (1,3),(1,4),(2,4),(3,5),(3,6),(4,6),(5,7),(5,8),(6,9),(6,10),(7,11),(7,12),(8,12),(9,13),(9,14);
/*!40000 ALTER TABLE `projects_students` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projects_teachers`
--

DROP TABLE IF EXISTS `projects_teachers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projects_teachers` (
  `project_id` int NOT NULL,
  `teacher_id` int NOT NULL,
  PRIMARY KEY (`project_id`,`teacher_id`),
  KEY `fk_projects_teachers_teachers` (`teacher_id`),
  CONSTRAINT `fk_projects_teachers_projects` FOREIGN KEY (`project_id`) REFERENCES `projects` (`project_id`),
  CONSTRAINT `fk_projects_teachers_teachers` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`teacher_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects_teachers`
--

LOCK TABLES `projects_teachers` WRITE;
/*!40000 ALTER TABLE `projects_teachers` DISABLE KEYS */;
INSERT INTO `projects_teachers` VALUES (4,1),(3,2),(2,3),(1,4),(6,5),(5,6),(10,7),(8,8),(9,9),(7,10);
/*!40000 ALTER TABLE `projects_teachers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `students` (
  `student_id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) NOT NULL,
  `middle_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `school_name` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `number_in_class` int NOT NULL,
  `birthdate` date DEFAULT NULL,
  PRIMARY KEY (`student_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students`
--

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` VALUES (1,'Кристина','Йорданова','Калчева','НЕГ ГЬОТЕ','11В',2,'2005-10-29'),(2,'Мартин','Стоилов','Димитров','НЕГ ГЬОТЕ','11В',3,'2005-12-17'),(3,'Таня','Димитрова','Тодорова','НЕГ ГЬОТЕ','11В',4,'2005-07-22'),(4,'Павел','Георгиев','Григоров','НЕГ ГЬОТЕ','11В',5,'2005-04-08'),(5,'Николай','Петров','Димитров','НЕГ ГЬОТЕ','11Г',1,'2005-02-15'),(6,'Светлана','Иванова','Симеонова','НЕГ ГЬОТЕ','11Г',2,'2005-06-11'),(7,'Златка','Николова','Георгиева','НЕГ ГЬОТЕ','11Г',3,'2005-09-30'),(8,'Марин','Кирилов','Петков','НЕГ ГЬОТЕ','11Г',4,'2005-01-17'),(9,'Борис','Петков','Тонев','НЕГ ГЬОТЕ','11Г',5,'2005-11-04'),(10,'Денис','Радев','Иванов','НЕГ ГЬОТЕ','11А',1,'2005-05-05'),(11,'Никола','Маринов','Богданов','НЕГ ГЬОТЕ','11А',2,'2005-04-22'),(12,'Мария','Петрова','Николова','НЕГ ГЬОТЕ','11А',3,'2005-06-18'),(13,'Тимотей','Тодоров','Михайлов','НЕГ ГЬОТЕ','11Б',4,'2005-01-29'),(14,'Силвия','Костова','Георгиева','НЕГ ГЬОТЕ','11Б',5,'2005-10-11');
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teachers`
--

DROP TABLE IF EXISTS `teachers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `teachers` (
  `teacher_id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) NOT NULL,
  `middle_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `school_name` varchar(255) NOT NULL,
  `birthdate` date DEFAULT NULL,
  PRIMARY KEY (`teacher_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teachers`
--

LOCK TABLES `teachers` WRITE;
/*!40000 ALTER TABLE `teachers` DISABLE KEYS */;
INSERT INTO `teachers` VALUES (1,'Иван','Аврамов','Пенев','НЕГ ГЬОТЕ','1985-05-14'),(2,'Мария','Александрова','Димитрова','НЕГ ГЬОТЕ','1990-11-23'),(3,'Георги','Алексеев','Хаджиев','НЕГ ГЬОТЕ','1978-09-10'),(4,'Анна','Борисова','Тодорова','НЕГ ГЬОТЕ','1983-02-18'),(5,'Петър','Иванов','Георгиев','НЕГ ГЬОТЕ','1975-06-05'),(6,'Елена','Николова','Костова','НЕГ ГЬОТЕ','1989-04-30'),(7,'Димитър','Николов','Караджов','НЕГ ГЬОТЕ','1980-12-22'),(8,'Виктория','Тодорова','Маринова','НЕГ ГЬОТЕ','1992-01-15'),(9,'Стефан','Георгиев','Николов','НЕГ ГЬОТЕ','1982-08-03'),(10,'Радка','Петрова','Станчева','НЕГ ГЬОТЕ','1987-11-09');
/*!40000 ALTER TABLE `teachers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-02 12:46:21
