﻿using MachineOperations;

Airplane airplane = new Airplane();
Car car = new Car();
LawnMower mower = new LawnMower();
Truck truck = new Truck();

MachineOperator pilot = new MachineOperator(airplane);
pilot.Start();
pilot.Stop();

pilot.Entity = car;
pilot.Start();
pilot.Stop();

pilot.Entity = mower;
pilot.Start();
pilot.Stop();

pilot.Entity = truck;
pilot.Start();
pilot.Stop();





        
     
