﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MachineOperations
{
    public class Truck : IMachine
    {
        public Truck()
        {
            Type = "Truck";
        }

        public string Type { get ; set ; }

        public void Start()
        {
            Console.WriteLine("Truck starting...");
        }

        public void Stop()
        {
            Console.WriteLine("Truck starting...");
        }
    }
}
