﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MachineOperations
{
    public class MachineOperator
    {
		private IMachine entity;

		public IMachine Entity
		{
			get { return entity; }
			set { entity = value;
                Console.WriteLine($"Machine operator is now running: {entity.Type}");
				}
		}

        public MachineOperator(IMachine entity)
        {
            Entity = entity;
        }
        public void Start()
        {
            Entity.Start();
        }

        public void Stop()
        {
            Entity.Stop();
        }

    }
}
