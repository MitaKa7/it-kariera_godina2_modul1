﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MachineOperations
{
    public class LawnMower : IMachine
    {
        public LawnMower()
        {
            Type = "Lawn Mower";
        }

        public string Type { get ; set; }

        public void Start()
        {
            Console.WriteLine("Lawn Mower starting...");
        }

        public void Stop()
        {
            Console.WriteLine("Lawn Mower stopping...");
        }
    }
}
