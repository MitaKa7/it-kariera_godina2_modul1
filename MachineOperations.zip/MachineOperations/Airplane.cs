﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MachineOperations
{
    public class Airplane : IMachine
    {
        public Airplane()
        {
            Type = "Airplane";
        }

        public string Type { get; set ; }

        public void Start()
        {
            Console.WriteLine("Airplane starting...");
        }

        public void Stop()
        {
            Console.WriteLine("Airplane stopping...");
        }
    }
}
