﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MachineOperations
{
    public class Car : IMachine
    {
        public string Type { get; set; }

        public void Start()
        {
            Console.WriteLine("Car starting...");
        }

        public void Stop()
        {
            Console.WriteLine("Car stoping...");
        }
        public Car()
        {
            Type = "Car";
        }
    }
}
